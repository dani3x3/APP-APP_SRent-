package APP_SRent;
import java.util.Date;

public class Asignacion {
    private String nombre;
    private String rut;
    private String direccion;
    private String telefono;
    private Date fechaRegistro;
    private Date fechaDevolucion;

    public Asignacion(String nombre, String rut, String direccion, String telefono, Date fechaRegistro) {
        this.nombre = nombre;
        this.rut = rut;
        this.direccion = direccion;
        this.telefono = telefono;
        this.fechaRegistro = fechaRegistro;
        // Calcular la fecha de devolución como fechaRegistro + 8 días
        this.fechaDevolucion = new Date(fechaRegistro.getTime() + (8 * 24 * 60 * 60 * 1000));
    }

    // Getters y Setters

    public String getNombre() {
        return nombre;
    }

    public String getRut() {
        return rut;
    }

    public String getDireccion() {
        return direccion;
    }

    public String getTelefono() {
        return telefono;
    }

    public Date getFechaRegistro() {
        return fechaRegistro;
    }

    public Date getFechaDevolucion() {
        return fechaDevolucion;
    }

	public void setFechaDevolucion(Date fechaDevolucion2) {
		// TODO Auto-generated method stub
		
	}
}
