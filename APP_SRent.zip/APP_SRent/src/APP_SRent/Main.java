package APP_SRent;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Inventario inventario = new Inventario();

        System.out.println("Bienvenido a la gestión de inventario y servicios de alquiler de cámaras.");

        while (true) {
            System.out.println("\nMenu:");
            System.out.println("1. Servicio Técnico");
            System.out.println("2. Gestión de Inventario");
            System.out.println("3. Salir");

            int opcionMenu = scanner.nextInt();
            switch (opcionMenu) {
                case 1:
                    gestionarServicioTecnico();
                    break;
                case 2:
                    gestionarInventario(inventario);
                    break;
                case 3:
                    System.out.println("¡Hasta luego!");
                    return;
                default:
                    System.out.println("Opción no válida. Por favor, ingrese una opción válida.");
            }
        }
    }

    private static void gestionarInventario(Inventario inventario) {
        Scanner scanner = new Scanner(System.in);

        // Paso 1: Escoger Marca
        System.out.println("Inventario de Cámaras");
        System.out.println("Escoger Marca:");
        System.out.println("1. Fuji");
        System.out.println("2. Sony");
        System.out.println("3. Nikon");

        int opcionMarca = scanner.nextInt();
        String marcaElegida = "";
        switch (opcionMarca) {
            case 1:
                marcaElegida = "Fuji";
                break;
            case 2:
                marcaElegida = "Sony";
                break;
            case 3:
                marcaElegida = "Nikon";
                break;
            default:
                System.out.println("Opción no válida");
                return;
        }

        // Paso 2: Escoger Modelo e ISO
        System.out.println("Escoger Modelo e ISO para la marca " + marcaElegida + ":");
        mostrarModelosParaMarca(marcaElegida);
        int opcionModelo = scanner.nextInt();
        String[] modeloISOStock = obtenerModeloISOStockParaMarca(marcaElegida, opcionModelo);
        String modeloElegido = modeloISOStock[0];
        String iso = modeloISOStock[1];
        int stock = Integer.parseInt(modeloISOStock[2]);

        // Paso 3: Registrar Asignación
        System.out.println("Ingresa tus datos para registrar la asignación:");
        System.out.print("Nombre: ");
        String nombre = scanner.next();
        System.out.print("Rut: ");
        String rut = scanner.next();
        System.out.print("Dirección: ");
        String direccion = scanner.next();
        System.out.print("Teléfono: ");
        String telefono = scanner.next();

        // Fecha de registro
        Date fechaRegistro = new Date();

        // Buscar la cámara seleccionada en el inventario
        Camara camaraAsignada = inventario.buscarPorMarcaModelo(marcaElegida, modeloElegido);
        if (camaraAsignada == null) {
            System.out.println("Lo sentimos, la cámara seleccionada no se encuentra en el inventario.");
            return; // Salir del método si la cámara no está en el inventario
        }

        // Crear la asignación
        Asignacion asignacion = new Asignacion(nombre, rut, direccion, telefono, fechaRegistro);
        // Registrar la asignación
        Date mensaje = inventario.registrarAsignacion(camaraAsignada, asignacion);
        System.out.println(mensaje);
    }

    private static void mostrarModelosParaMarca(String marca) {
        switch (marca) {
            case "Fuji":
                System.out.println("1. E34R - ISO 1600 - Stock 10");
                System.out.println("2. M56 - ISO 400 - Stock 4");
                break;
            case "Sony":
                System.out.println("1. Laser - ISO 50 - Stock 4");
                System.out.println("2. P78 - ISO 200 - Stock 5");
                break;
            case "Nikon":
                System.out.println("1. X65 - ISO 800 - Stock 10");
                System.out.println("2. XV - ISO 100 - Stock 4");
                break;
            default:
                System.out.println("Marca no válida");
        }
    }

    private static String[] obtenerModeloISOStockParaMarca(String marca, int opcion) {
        switch (marca) {
            case "Fuji":
                switch (opcion) {
                    case 1:
                        return new String[]{"E34R", "ISO 1600", "10"};
                    case 2:
                        return new String[]{"M56", "ISO 400", "4"};
                    default:
                        return new String[]{"", "", ""};
                }
            case "Sony":
                switch (opcion) {
                    case 1:
                        return new String[]{"Laser", "ISO 50", "4"};
                    case 2:
                        return new String[]{"P78", "ISO 200", "5"};
                    default:
                        return new String[]{"", "", ""};
                }
            case "Nikon":
                switch (opcion) {
                    case 1:
                        return new String[]{"X65", "ISO 800", "10"};
                    case 2:
                        return new String[]{"XV", "ISO 100", "4"};
                    default:
                        return new String[]{"", "", ""};
                }
            default:
                return new String[]{"", "", ""};
        }
    }

    private static void gestionarServicioTecnico() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Gestión de Servicio Técnico");

        // Opciones de marca
        System.out.println("Escoger Marca:");
        System.out.println("1. Fuji");
        System.out.println("2. Sony");
        System.out.println("3. Nikon");

        int opcionMarca = scanner.nextInt();
        String marca = "";
        switch (opcionMarca) {
            case 1:
                marca = "Fuji";
                break;
            case 2:
                marca = "Sony";
                break;
            case 3:
                marca = "Nikon";
                break;
            default:
                System.out.println("Opción no válida");
                return;
        }

        // Mostrar información del servicio técnico para la marca seleccionada
        System.out.println("Servicio Técnico para la marca " + marca + ":");
        ServicioT servicioTecnico = obtenerServicioTecnicoParaMarca(marca);
        if (servicioTecnico != null) {
            System.out.println("Dirección: " + servicioTecnico.getDireccion());
            System.out.println("Teléfono: " + servicioTecnico.getTelefono());
        } else {
            System.out.println("No hay información de servicio técnico para la marca " + marca);
        }
    }

    private static ServicioT obtenerServicioTecnicoParaMarca(String marca) {
        switch (marca) {
            case "Fuji":
                return new ServicioT("Servicio Técnico Fuji", "Dirección Fuji", "Teléfono Fuji");
            case "Sony":
                return new ServicioT("Servicio Técnico Sony", "Dirección Sony", "Teléfono Sony");
            case "Nikon":
                return new ServicioT("Servicio Técnico Nikon", "Dirección Nikon", "Teléfono Nikon");
            default:
                return null;
        }
    }
}
