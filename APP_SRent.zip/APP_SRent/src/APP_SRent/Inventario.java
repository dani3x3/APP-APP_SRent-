package APP_SRent;

import java.util.ArrayList;
import java.util.List;
import java.util.Date;

public class Inventario {
    private List<Camara> camaras;

    public Inventario() {
        camaras = new ArrayList<>();
    }

    public void agregarCamara(Camara camara) {
        camaras.add(camara);
    }

    public Camara buscarPorMarcaModelo(String marca, String modelo) {
        for (Camara camara : camaras) {
            if (camara.getMarca().equals(marca) && camara.getModelo().equals(modelo)) {
                return camara;
            }
        }
        return null;
    }

    public Date registrarAsignacion(Camara camara, Asignacion asignacion) {
        // Calcular la fecha de devolución (8 días después de la fecha de registro)
        long ochoDiasEnMilisegundos = 8 * 24 * 60 * 60 * 1000L;
        Date fechaDevolucion = new Date(asignacion.getFechaRegistro().getTime() + ochoDiasEnMilisegundos);
        asignacion.setFechaDevolucion(fechaDevolucion);
        return fechaDevolucion;
    }
    
    public void setFechaDevolucion(Date fechaDevolucion) {
        // Este método se podría utilizar para establecer manualmente la fecha de devolución en caso necesario
        // Podría ser útil para futuras extensiones de la funcionalidad del programa
        // Por ahora, no necesitamos implementarlo
    }
}
