package APP_SRent;
public class Camara {
    private String marca;
    private String modelo;
    private String iso;
    private int stock;

    public Camara(String marca, String modelo, String iso, int stock) {
        this.marca = marca;
        this.modelo = modelo;
        this.iso = iso;
        this.stock = stock;
    }

    // Métodos para acceder a los atributos
    public String getMarca() {
        return marca;
    }

    public String getModelo() {
        return modelo;
    }

    public String getISO() {
        return iso;
    }

    public int getStock() {
        return stock;
    }
}
