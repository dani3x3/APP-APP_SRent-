package APP_SRent;

//Clase ServicioT
public class ServicioT {
 private String marca;
 private String direccion;
 private String telefono;

 public ServicioT(String marca, String direccion, String telefono) {
     this.marca = marca;
     this.direccion = direccion;
     this.telefono = telefono;
 }

 // Getters y setters
 public String getMarca() {
     return marca;
 }

 public void setMarca(String marca) {
     this.marca = marca;
 }

 public String getDireccion() {
     return direccion;
 }

 public void setDireccion(String direccion) {
     this.direccion = direccion;
 }

 public String getTelefono() {
     return telefono;
 }

 public void setTelefono(String telefono) {
     this.telefono = telefono;
 }
}
